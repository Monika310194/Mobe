//
//  OrderHistoryPage.swift
//  Namitha_try
//
//  Created by MacBook-Pro-4 on 05/03/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import UIKit

class OrderHistoryPage: UIViewController {
    //VARIABLES:
    var emailId = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .yellow
        emailId = "namithapavithran94@gmail.com"
        let url = "https://evening-chamber-14219.herokuapp.com/order/getOrderByEmailID/"+emailId
        print("urllllll",url)
       
        let networkCall = NetworkHandler()
        networkCall.networkDelegate = self
        networkCall.fetchJSON(url: url)

    }
   
    

}

/*extension OrderHistoryPage: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        <#code#>
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        <#code#>
    }
 
    
}*/
extension OrderHistoryPage: NetWorkProtocol{
    func sendJSON(data: Data) {
        
        let data = data
        
        do{
            
            let orders = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [Any]
            
            print(orders)
            
           
                CustomLoader.activity.stopLoader()
            }
            
            
            
         catch let jsonErr {
            print("error serialising json :",jsonErr)
        }
        
    }

}

