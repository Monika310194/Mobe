//
//  DPrint.swift
//  Mobe
//
//  Created by user on 07/03/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import Foundation
import UIKit

private var debug: Bool = true

func DPrint(_ Items: Any...)
{
    if debug
    {
        var output: String = ""
        for i in Items
        {
            output = output + String(describing: i)
        }
        print(output)
    }
}
