//
//  AppDelegate.swift
//  MOBE
//
//  Created by user143649 on 3/16/19.
//  Copyright © 2019 user143649. All rights reserved.
//

//fb login app id: 368652830386286
import UIKit
import FacebookCore
import GoogleSignIn
import FBSDKLoginKit
import GoogleMaps
import GooglePlaces
import FacebookLogin

var userData: UserLogin?

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate,GIDSignInDelegate {
    
    
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            print("\(error.localizedDescription)")
        } else {
            
            // Perform any operations on signed in user here.
            let userId = user.userID                  // For client-side use only!
            let idToken = user.authentication.idToken // Safe to send to the server
            let fullName = user.profile.name
            let givenName = user.profile.givenName
            let familyName = user.profile.familyName
            let email = user.profile.email
            let image = user.profile.imageURL(withDimension: 120)
            print("Google sign in Success!! ",userId ?? "no value","\n",idToken ?? "no value","\n",fullName ?? "no value","\n",givenName ?? "no value","\n",familyName ?? "no value","\n",familyName ?? "no value","\n",email ?? "no value","\n",image ?? "no value" )
            
            var profile = [String:Any]()
            profile["NAME"] = fullName
            profile["EMAIL"] = email
             profile["SOURCE"] = "G"
             profile["USER_TYPE"] = "USER"
            orderData["USER_ID"] = email
            //post user profile info to backend
            
            guard let credentialsUrl = URL(string: "https://evening-chamber-14219.herokuapp.com/users/createUser") else{ return}
            var request = URLRequest(url: credentialsUrl)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            // guard let httpBody = try? JSONSerialization.data(withJSONObject: patternsDict, options: [])else{return}
            let httpBody =  try? JSONSerialization.data(withJSONObject: profile)
            request.httpBody = httpBody
            let session = URLSession.shared
            session.dataTask(with: request){(data,response,error)in
                if error == nil{
                    if let response = response{
                        print("response ",response,"\n","data ",data)
                    }
                }
                else{
                    print("error while posting user info: ",error as! NSError)
                }
               
                }.resume()
            
            if let image = image{
                
                userData = UserLogin(name: fullName ?? "nil", urlPath: image, mailId: email ?? "nil")
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let initialViewController = storyboard.instantiateViewController(withIdentifier: "navController") as! UINavigationController
                
                window?.rootViewController = initialViewController
                window?.makeKeyAndVisible()
               
            }
        }
    }
    

    var window: UIWindow?

    func loginWithFacebook() {
        //Check for previous Access Token
        if let accessToken  = AccessToken.current {
            //AccessToken was obtained during same session
            getAccountDetails(withAccessToken: accessToken)
        }
        else if let strAuthenticationToken = UserDefaults.standard.string(forKey: "AccessToken_Facebook") {
            //A previous access token string was saved so create the required AccessToken object
            let accessToken = AccessToken(authenticationToken: strAuthenticationToken)
            
            //Skip Login and directly proceed to get facebook profile data with an AccessToken
            getAccountDetails(withAccessToken: accessToken)
        }
        else {
            //Access Token was not available so do the normal login flow to obtain the Access Token
            doFacebookLogin()
        }
    }
    func doFacebookLogin() {
        LoginManager().logIn(readPermissions: [.publicProfile, .email], viewController: nil) { loginResult in
            switch loginResult {
            case .failed(let error):
                print(error)
                
            case .cancelled:
                print("User cancelled login.")
                
            case .success(let grantedPermissions,
                          let declinedPermissions,
                          let accessToken):
                
                //Save Access Token string for silent login purpose later
                let strAuthenticationToken = accessToken.authenticationToken
                UserDefaults.standard.set(strAuthenticationToken,
                                          forKey: "AccessToken_Facebook")
                
                //Proceed to get facebook profile data
                self.getAccountDetails(withAccessToken: accessToken)
            }
        }
    }
    func getAccountDetails(withAccessToken accessToken: AccessToken) {
        let graphRequest: GraphRequest = GraphRequest(graphPath     : "me",
                                                      parameters    : ["fields" : "id, name, email"],
                                                      accessToken   : accessToken,
                                                      httpMethod    : GraphRequestHTTPMethod.GET,
                                                      apiVersion    : GraphAPIVersion.defaultVersion)
        graphRequest.start { (response, result) in
            switch result {
            case .success(let resultResponse):
                print("resultResponse ",resultResponse)
            case .failed(let error):
                print("error ",error)
            }
        }
    }

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        GMSServices.provideAPIKey("AIzaSyC907BQBnrZK0UjA2zARtE6Mq7L__yqw5Q")
        GMSPlacesClient.provideAPIKey("AIzaSyC907BQBnrZK0UjA2zARtE6Mq7L__yqw5Q")
        //Facebook login
        
        if let strAuthenticationToken = UserDefaults.standard.string(forKey: "AccessToken_Facebook") {
            print("fb login access token found")
            //Create AccessToken for facebook login
          //  let accessToken = AccessToken(authenticationToken: strAuthenticationToken)
            //print(accessToken.userId)
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
           // getAccountDetails(withAccessToken: accessToken)
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "navController") as! UINavigationController
            
            window?.rootViewController = initialViewController
            window?.makeKeyAndVisible()
            
        }
        else{
            print("fb login : new login")
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let loginViewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginVC
             window?.rootViewController = loginViewController
        }

       /* if let accessToken = AccessToken.current {
            // User is logged in, use 'accessToken' here.
            print("access token ",accessToken.userId ?? "no value")
        }
        else{
            print("fb : user not logged in")
        }*/
        
        //Google login
        GIDSignIn.sharedInstance().clientID="1075348529232-t2u54r3b90v3c98vp0dtkbf0j1vfpbkj.apps.googleusercontent.com"
        
        GIDSignIn.sharedInstance()?.delegate = self
        
        if (GIDSignIn.sharedInstance()?.hasAuthInKeychain())! {
            
            GIDSignIn.sharedInstance()?.signInSilently()
       
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let initialViewController = storyboard.instantiateViewController(withIdentifier: "navController") as! UINavigationController
        
            window?.rootViewController = initialViewController
            window?.makeKeyAndVisible()
      
        }
        else{
            
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let loginViewController = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginVC
          
           
            window?.rootViewController = loginViewController
        }
        
        return FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)

    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        
        return SDKApplicationDelegate.shared.application(app, open: url, options: options)
    }
        
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    }

}

