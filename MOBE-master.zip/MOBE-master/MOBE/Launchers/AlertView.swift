//
//  AlertView.swift
//  MOBE
//
//  Created by user143649 on 3/19/19.
//  Copyright © 2019 user143649. All rights reserved.
//

import UIKit
import GoogleSignIn

class AlertView:UIViewController{
    
    var delegate: CustomAlertViewDelegate?
    let blackView = UIView()
    var alertView = UIView()
    
    func removeAlert(){
        blackView.removeFromSuperview()
        alertView.removeFromSuperview()
    }
   
    func loadAlert(title: String,subtitle: String,negativeAction:String,positiveAction:String){
    
       if let window = UIApplication.shared.keyWindow{
        blackView.alpha = 0.5
        window.addSubview(blackView)
        blackView.frame = window.frame
        
        //Customize alert view
        let x = window.frame.width*0.1
        let width = window.frame.width - (x*2)
        let height = window.frame.height * 0.2
        let y = window.frame.height/2 - height/2
        
        alertView = UIView(frame: CGRect(x: x, y: y, width: width, height: height))
        window.addSubview(alertView)
        alertView.backgroundColor = UIColor.darkGray
        
        //Put subviews inside alert view
        let lblTitle = UILabel()
        let lblSubTitle = UILabel()
        let btnYes = UIButton()
        let btnNo = UIButton()
        
        var views = [String: UIView]()
        views["title"] = lblTitle
        views["subtitle"] = lblSubTitle
        views["btnYes"] = btnYes
        views["btnNo"] = btnNo
        
        for (_,value) in views{
            alertView.addSubview(value)
            value.translatesAutoresizingMaskIntoConstraints = false
        }
        
        let horConstraint1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[title]", options: [], metrics: nil, views: views)
        let horConstraint2 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[subtitle]", options: [], metrics: nil, views: views)
        let verConstraint1 = NSLayoutConstraint.constraints(withVisualFormat: "V:|-[title]-[subtitle]", options: [.alignAllCenterX], metrics: nil, views: views)
        
        let negwidth = negativeAction.count*8
        let poswidth = positiveAction.count*8
        let metric = ["wid1":negwidth,"wid2":poswidth]
        let verConstraint2 = NSLayoutConstraint.constraints(withVisualFormat: "V:[btnNo(25)]-|", options: [], metrics: nil, views: views)
        let verConstraint3 = NSLayoutConstraint.constraints(withVisualFormat: "V:[btnYes(25)]-|", options: [], metrics: nil, views: views)
        let horConstraint3 = NSLayoutConstraint.constraints(withVisualFormat: "H:[btnNo(wid1)]-[btnYes(wid2)]-|", options: [], metrics: metric, views: views)
        
        alertView.addConstraints(horConstraint1)
         alertView.addConstraints(verConstraint1)
         alertView.addConstraints(verConstraint2)
         alertView.addConstraints(verConstraint3)
         alertView.addConstraints(horConstraint2)
        alertView.addConstraints(horConstraint3)
        
        lblTitle.textColor = .white
        lblSubTitle.textColor = .white
        btnNo.setTitleColor(.white, for: .normal)
        btnYes.setTitleColor(.white, for: .normal)
        btnNo.addTarget(self, action: #selector(noTapped), for: .touchUpInside)
         btnYes.addTarget(self, action: #selector(yesTapped), for: .touchUpInside)
        
        lblTitle.text = title
        lblSubTitle.text = subtitle
        btnNo.setTitle(negativeAction, for: .normal)
        btnYes.setTitle(positiveAction, for: .normal)
        
        lblTitle.font = UIFont.systemFont(ofSize: 16)
        lblSubTitle.font = UIFont.systemFont(ofSize: 12)
        btnNo.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        btnYes.titleLabel?.font = UIFont.systemFont(ofSize: 12)

    }
    }
    
    @objc func noTapped(){
        //dismiss the view
        blackView.removeFromSuperview()
        alertView.removeFromSuperview()
        delegate?.negativeButtonTapped()
    }
    @objc func yesTapped(){
        blackView.removeFromSuperview()
        alertView.removeFromSuperview()
        delegate?.positiveTapped()
    }
}
