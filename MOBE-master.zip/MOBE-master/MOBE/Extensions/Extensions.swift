//
//  Extensions.swift
//  Mobe
//
//  Created by MacBook-Pro-4 on 16/02/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import Foundation
import UIKit

extension UILabel{
    
    func rotateArrowUp(){
        self.transform = CGAffineTransform(rotationAngle: CGFloat.pi / 2)
    }
    func rotateArrowDown(){
        self.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 2)
    }
}

let imageCache = NSCache<AnyObject, AnyObject>()

class CustomImageView: UIImageView{
    
    var imageFromUrl: String?
    func loadImageFromUrl(urlStr: String){
        
        imageFromUrl = urlStr
        
        if let imageFROMcache = imageCache.object(forKey: urlStr as AnyObject) as? UIImage{
            self.image = imageFROMcache
            return
        }
        
        guard  let url = URL(string: urlStr) else {return}
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil{
                print(error!)
                return
            }
            DispatchQueue.main.async {
                
                guard let data = data else { return }
                
                guard let imageToCache = UIImage(data: data) else { return }
                
                if self.imageFromUrl == urlStr{
                    
                    self.image = imageToCache
                    
                }
                imageCache.setObject(imageToCache, forKey: urlStr as AnyObject)
                
            }
        }.resume()
    }
}

extension UIView{
    func makeRound(){
        self.layer.cornerRadius = self.frame.width/2
        self.layer.masksToBounds = false
        self.layer.borderWidth = 1
        self.clipsToBounds = true
    }
}
extension UIViewController {
    
    func alert(message: String, title: String = "") {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(OKAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
}
extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
}
/*extension UIViewController{
    func activityIndicator ()
    {
        boxView = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        boxView.backgroundColor = UIColor.white
        boxView.alpha = 1.0
        boxView.layer.cornerRadius = 1
        
        //Here the spinnier is initialized
        activityView.frame = CGRect(x: view.frame.midX - 30, y: view.frame.midY - 25, width: 180, height: 50)
        activityView.color = UIColor(red: 57/255, green: 106/255, blue: 157/255, alpha: 1.0)
        
        let textLabel = UILabel(frame: CGRect(x: view.frame.midX - 90, y: view.frame.midY - 25, width: 180, height: 50))
        
        
        textLabel.textColor = UIColor(red: 17/255, green: 56/255, blue: 113/255, alpha: 1.0)//UIColor.darkGray
        textLabel.text = "Loading Data"
        textLabel.font = UIFont(name: "Akkurat",size: 20) //.systemFont(ofSize: 20.0)
        
        boxView.addSubview(activityView)
        boxView.addSubview(textLabel)
        view.addSubview(boxView)
    }
    
    
    func Start_ActivityIndicator() {
        DispatchQueue.main.async {
            self.activityIndicator()
            activityView.startAnimating()
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    func Stop_ActivityIndicator() {
        DispatchQueue.main.async {
            activityView.stopAnimating()
            boxView.isHidden = true
            activityView.hidesWhenStopped = true
            boxView.removeFromSuperview()
            activityView.removeFromSuperview()
            
            UIApplication.shared.endIgnoringInteractionEvents()
        }
}*/

    func setupNavigation(navigationItem:UINavigationItem) {
    var rightBarBtns = [UIBarButtonItem]()
    var LeftBarBtns = [UIBarButtonItem]()
    let imgLoactionMap:UIImageView =  UIImageView(frame: CGRect(x: 2, y: 3, width: 30, height: 30))//x:5
    let x = 10
    let btnLoactionMap :UIButton =  UIButton(frame: CGRect(x:0, y:0 ,width:3*x,height:5*x))
    btnLoactionMap.addSubview(imgLoactionMap)
    imgLoactionMap.image = UIImage.init(named: "map icon")?.withRenderingMode(.alwaysOriginal)
        
     // image placed on btnMenu
    let menuImage:UIImageView = UIImageView(frame: CGRect(x:5, y: 0, width: 30, height: 30))
    
    // background button(on button there is image(menuImage)
    let btnMenu = UIButton(frame: CGRect(x:0, y:0 ,width:4*x,height:5*x))
    menuImage.image = UIImage.init(named: "menu icon")?.withRenderingMode(.alwaysOriginal)
       
    
    btnMenu.addSubview(menuImage)
    let rightbarbtn2 = UIBarButtonItem(customView: btnLoactionMap)
    rightBarBtns.append(rightbarbtn2)
    
    let Leftbutton = UIBarButtonItem(customView: btnMenu)
    LeftBarBtns.append(Leftbutton)
    navigationItem.setLeftBarButtonItems(LeftBarBtns, animated: true)
    navigationItem.setRightBarButtonItems(rightBarBtns, animated: true)
    
    
}
