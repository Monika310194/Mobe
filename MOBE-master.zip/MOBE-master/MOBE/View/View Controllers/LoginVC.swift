//
//  LoginVC.swift
//  Mobe
//
//  Created by user on 28/02/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import FacebookLogin
import GoogleSignIn
import FacebookCore


class LoginVC: UIViewController,FBSDKLoginButtonDelegate,GIDSignInUIDelegate {
    let getPostValueForFacebook = [Any]()
    var postDataDictionary = ["NAME":"","EMAIL":"","USER_ID":""]
    var patternsDict =  [String : String]()
    var arrayValue = [String]()
    var outletId:String?
    var fullName:String?
    var facebookProfileID:String?
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
       // let strAuthenticationToken = AccessToken.current
       // UserDefaults.standard.set(strAuthenticationToken,
                                  //forKey: "AccessToken_Facebook")
      // loginButtonClicked()
        getFBUserData()
    //   doFacebookLogin()
        
    }
   /* func doFacebookLogin() {
        print("inside doFacebookLogin")
        LoginManager().logIn(readPermissions: [.publicProfile, .email], viewController: nil) { loginResult in
            switch loginResult {
            case .failed(let error):
                print(error)
                
            case .cancelled:
                print("User cancelled login.")
                
            case .success(let grantedPermissions,
                          let declinedPermissions,
                          let accessToken):
                
                //Save Access Token string for silent login purpose later
                let strAuthenticationToken = accessToken.authenticationToken
                UserDefaults.standard.set(strAuthenticationToken,
                                          forKey: "AccessToken_Facebook")
                
                //Proceed to get facebook profile data
                self.getAccountDetails(withAccessToken: accessToken)
            }
        }
    }*/
   /* func getAccountDetails(withAccessToken accessToken: AccessToken) {
        print("inside getAccountDetails")
        let graphRequest: GraphRequest = GraphRequest(graphPath     : "me",
                                                      parameters    : ["fields" : "id, name, email"],
                                                      accessToken   : accessToken,
                                                      httpMethod    : GraphRequestHTTPMethod.GET,
                                                      apiVersion    : GraphAPIVersion.defaultVersion)
        graphRequest.start { (response, result) in
            switch result {
            case .success(let resultResponse):
                print("result response ",resultResponse)
                var profile = [String:Any]()
                profile["NAME"] = fullName
                profile["EMAIL"] = email
                profile["SOURCE"] = "F"
                profile["USER_TYPE"] = "USER"
                orderData["USER_ID"] = email
                //post user profile info to backend
              
                self.postFBData()
            case .failed(let error):
                print("error ",error)
            }
        }
    }*/
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
         print("logout")
       
    }
    

    @IBOutlet weak var btnFacebookLogin: FBSDKLoginButton!
   // var userData: UserLogin?
   
 
    func postFBData(){
        
        guard let credentialsUrl = URL(string: "https://evening-chamber-14219.herokuapp.com/users/createUser") else{ return}
        var request = URLRequest(url: credentialsUrl)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        // guard let httpBody = try? JSONSerialization.data(withJSONObject: patternsDict, options: [])else{return}
        let httpBody = try? JSONSerialization.data(withJSONObject: postDataDictionary)
        request.httpBody = httpBody
        let session = URLSession.shared
        session.dataTask(with: request){(data,response,error)in
            if let response = response{
                print("response",response)
            }
            if let data = data{
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                   
                        
                        self.performSegue(withIdentifier: "showOutlets", sender: (Any).self)
                  
                }catch{
                    print("",error)
                }
                
            }
            }.resume()
        
    }
  
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user: GIDGoogleUser!,
              withError error: Error!) {
        // Perform any operations when the user disconnects from app here.
        // ...
    }
    
    @IBAction func didTapSignOut(_ sender: AnyObject) {
        GIDSignIn.sharedInstance().signOut()
    }
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       if segue.identifier == "showOutlets" {
                if let destinationVC = segue.destination as? UINavigationController {
                    if let VC = destinationVC.viewControllers.first as? BarLoaction{
                    VC.userInfo = userData
                    }
                }
            }
    }*/
        
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnFacebookLogin.readPermissions = [ReadPermission.publicProfile,ReadPermission.email]
  //com.googleusercontent.apps.1075348529232-t2u54r3b90v3c98vp0dtkbf0j1vfpbkj
     
        //GIDSignIn.sharedInstance().delegate = self
        
        GIDSignIn.sharedInstance().uiDelegate = self
        btnFacebookLogin.readPermissions = ["public_profile","email"]
        btnFacebookLogin.delegate = self
       /* if let accessToken = FBSDKAccessToken.current(){
            print("accessToken fb ",accessToken)
            
            getFBUserData()
        }*/
        
        // Do any additional setup after loading the view.
    }
    
    
     func loginButtonClicked() {
        print("inside loginButtonClicked")
        let loginManager = LoginManager()
        // loginManager.lo([ .publicProfile], viewController: self) { loginResult in
        loginManager.logIn(readPermissions: [ ReadPermission.email], viewController: self) { loginResult in
            print("loginResult ",loginResult)
            switch loginResult {
            case .failed(let error):
                print("failed case :",error)
            case .cancelled:
                print("User cancelled login.")
            case .success(let grantedPermissions, let declinedPermissions, let accessToken):
                self.getFBUserData()
            }
        }
    }
    
    //function is fetching the user data
    func getFBUserData(){
        
        if((FBSDKAccessToken.current()) != nil)
        {
            let strAuthenticationToken = AccessToken.current
            UserDefaults.standard.set(strAuthenticationToken?.authenticationToken,
                                      forKey: "AccessToken_Facebook")
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "name, email, id"]).start(completionHandler:
                { (connection, result, error) -> Void in
                    
                    if (error == nil)
                    {
                        print("result ",result)
                        //everything works print the user data
                        if let data = result as? NSDictionary
                        {
                            print("data",data)
                            for(key,value) in data{
                                self.arrayValue.append(value as! String)
                            }
                            //change this after getting email id
                            self.arrayValue.append("namithapavithran94@gmail.com")
                            self.postDataDictionary.updateValue(data["id"] as! String, forKey: "USER_ID")
                            self.postDataDictionary.updateValue(data["name"] as! String , forKey: "NAME")
                            self.postDataDictionary.updateValue(self.arrayValue[2] , forKey: "EMAIL")
                           
                            self.postDataDictionary.updateValue("USER" , forKey: "USER_TYPE")
                            self.postDataDictionary.updateValue("F" , forKey: "SOURCE")
                            self.facebookProfileID = data["id"] as? String
                            
                            //after getting email id put the email id from data
                             orderData["USER_ID"] = "namithapavithran94@gmail.com"
                            
                            self.fullName = data.object(forKey: "name") as? String
                            //let facebookProfile = URL(string: "http://graph.facebook.com/\(self.facebookProfileID!)/picture?type=large")
                          //  if let image = facebookProfile{
                            let facebookProfile = "http://graph.facebook.com/\(self.facebookProfileID!)/picture?type=large"
                            let fbImgUrl = URL(string: facebookProfile)
                            
                            userData = UserLogin(name: data["name"] as! String , urlPath: fbImgUrl!, mailId: self.arrayValue[2] )
                             
                                self.postFBData()
                                //self.performSegue(withIdentifier: "showOutlets", sender: (Any).self)
                          //  }
                          //  else
                          //  {
                                // If user have signup with mobile number you are not able to get their email address
                                print("We are unable to access Facebook account details, please use other sign in methods.")
                         //   }
                            
                        }
                    }
            })
             
        }
       
    }
    
}

