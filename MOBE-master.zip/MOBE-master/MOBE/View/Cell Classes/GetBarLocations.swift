//
//  GetBarLocations.swift
//  Mobe
//
//  Created by user on 03/03/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//


import UIKit

class GetBarLocations: UICollectionViewCell {
    
    @IBOutlet weak var lblLocation: UILabel!
}
