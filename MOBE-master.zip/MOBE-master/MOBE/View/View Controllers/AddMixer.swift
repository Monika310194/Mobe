//
//  AddMixer.swift
//  Mobe
//
//  Created by user on 01/03/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import UIKit


class AddMixer: UIViewController,NetWorkProtocol {
    
    //VARIABLES:-
   
    var ordersFromMixerPage = [OrderSummary]()
    @IBOutlet weak var btnProceed: UIButton!
    var mixerId:String?
    var mixerName:String?
    var mixerPrice:Int?
    var mixerDataList = [Any]()
    var lastSelectedCellIndex:IndexPath?
    let objQuantity = QuanityTableLauncher()
    var mixerProducts = [String:Any]()
    let quantityNotification = Notification.Name.init(QuantityForMixerPageNotiKey)
    struct Info{
        var name: String = ""
        var price: Int = 0
       
        
        init(typeName:String,price: Int) {
            name = typeName
            self.price = price
          
        }
        var quantity: Int = 0
        init(quantity: Int) {
            self.quantity = quantity
        }
    }
    var itemPresent = [Bool]()
    var mixerData = [Int: Info]()
    
    var queryDoneFormixerList:Bool?
    func sendJSON(data: Data) {
        let data = data
        do{
            
            mixerDataList = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [Any]
            print("mixerData",mixerDataList.count,mixerDataList)
            self.queryDoneFormixerList = true
            self.itemPresent = Array(repeating: false, count: mixerDataList.count)
            DispatchQueue.main.async {
                //self.mixerList = drinksData["mixerData"] as! [Any]
                self.mixerListCollectionView.reloadData()
                CustomLoader.activity.stopLoader()
            }
        } catch let jsonErr {
            print("error serialising json :",jsonErr)
        }
        
    }
    @IBAction func leftSkipBarButtonClick(_ sender: Any) {
       // ordersFromMixerPage.removeAll()
        if ordersForSummary.count>1{
            let mixerCount = ordersForSummary.count - 1
            
            ordersForSummary.removeLast(mixerCount)
            
        }
        
        performSegue(withIdentifier: "showOrderSummary", sender: self)
    }
   /* func notifySelectedIndex(indexpath:IndexPath){
        print("notification index",indexpath)
        let cell = mixerListCollectionView.cellForItem(at: indexpath) as! addMixerCell
        cell.lblNoOfQunatity.text = String(objQuantity.selectedQuantity)
        
    }*/
    
    
    @IBOutlet weak var mixerListCollectionView: UICollectionView!
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        
        // needed to clear the text in the back navigation:
        self.navigationItem.title = " "
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        self.navigationItem.title = "ADD MIXER"
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       // NotificationCenter.default.addObserver(self, selector: #selector(someFuncitonName), name: Notification.Name.TimeOutUserInteraction, object: nil)
        btnProceed.addTarget(self, action: #selector(ProccedToOrderSummary), for: .touchUpInside)
      //  navigationItem.title = "Add Mixer"
        navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
       
        NotificationCenter.default.addObserver(self, selector: #selector(updateQuantity(notification:)), name: quantityNotification, object: nil)
       
        let url = "https://evening-chamber-14219.herokuapp.com/mixer/getAllMixer"
        let networkCall = NetworkHandler()
        networkCall.networkDelegate = self
        networkCall.fetchJSON(url: url)
        
        mixerListCollectionView.delegate = self
        mixerListCollectionView.dataSource = self
        // doSomething(timeInterval: 10)
        
        // Do any additional setup after loading the view.
    }
    @objc func someFuncitonName()
    {
        alert(message: "dead", title: "end timer")
    }
    @objc func ProccedToOrderSummary()
    {
        print("ordersForSummary.count ",ordersForSummary.count)
        if ordersForSummary.count>1{
             let mixerCount = ordersForSummary.count - 1
           
                ordersForSummary.removeLast(mixerCount)
            
        }
        
      
        ordersForSummary.append(contentsOf: ordersFromMixerPage)
     //   print("before proceed ",ordersForSummary)
     performSegue(withIdentifier: "showOrderSummary", sender: self)
        
    }
    /*override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showOrderSummary" {
            if let destinationVC = segue.destination as? OrderSummaryPage {
                destinationVC.orders =  ordersForSummary
            }
        }
    }*/
    //update cell data
    @objc func updateQuantity(notification: Notification){
        if let userInfo = notification.userInfo{
        let quantity = userInfo["quantity"] as! Int
           
            let cell = mixerListCollectionView.cellForItem(at: lastSelectedCellIndex!) as! addMixerCell
            cell.lblNoOfQunatity.text = "\(quantity)"
            cell.btnCancel.isHidden = false
           
           
            if itemPresent[(lastSelectedCellIndex?.item)!]{
                print("inside if item present true ",itemPresent[(lastSelectedCellIndex?.item)!])
                  //  for index in 0..<ordersFromMixerPage.count{
                      //  if ordersFromMixerPage[index].index == (lastSelectedCellIndex?.item)!{
                            print("///quantiy inside  ////",quantity)
                let changedOrder = OrderSummary(itemName: mixerName ?? "no value", price: mixerPrice ?? 0, itemCount: userInfo["quantity"] as! Int, index: (lastSelectedCellIndex?.item)!, mixerId: mixerId)
                if let index = lastSelectedCellIndex?.item{
                            ordersFromMixerPage[index] = changedOrder
                }
                            print("before break ",ordersFromMixerPage)
                          //  break
                       // }
                       
                  //  }
            }
                    else{
                print("inside else item present false ",itemPresent[(lastSelectedCellIndex?.item)!])
                let orderSummary = OrderSummary(itemName:  mixerName ?? "no value", price: mixerPrice ?? 0, itemCount: quantity, index: (lastSelectedCellIndex?.item)!, mixerId: mixerId)
                        ordersFromMixerPage.append(orderSummary)
                
                    }
        }
            
        itemPresent[(lastSelectedCellIndex?.item)!] = true
    }
    
    @objc func cancelQuantity(sender:UIButton){
        print("refreshTheQunatityLabel sender",sender.tag)
        let indexPath = IndexPath(row: sender.tag, section: 0)
        
        let cell = mixerListCollectionView.cellForItem(at: indexPath ) as! addMixerCell
        cell.lblNoOfQunatity.text = ""
        cell.btnCancel.isHidden = true
        
        for i in 0..<ordersFromMixerPage.count{
            let order = ordersFromMixerPage[i]
            if order.index == sender.tag{
                ordersFromMixerPage.remove(at: i)
                break
            }
        }
    }
    
    
}

extension AddMixer:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return mixerDataList.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "mixerCell", for: indexPath) as! addMixerCell
        cell.btnCancel.tag = indexPath.item
        
        cell.btnCancel.addTarget(self, action: #selector(cancelQuantity(sender:)), for: .touchUpInside)
        guard let queryDone = queryDoneFormixerList else{ return cell}
        
        if queryDone{
           
            
            mixerProducts = mixerDataList[indexPath.item] as! [String:Any]
            cell.setUpData(mixerList: mixerProducts)
         
            
            cell.roundCorners(corners: [.topLeft,.topRight,.bottomLeft,.bottomRight], radius: 4.0)
            
        }
        else{
            print("return cell")
            return cell
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        lastSelectedCellIndex = indexPath
        objQuantity.pageIndex = 1
        mixerProducts = mixerDataList[indexPath.item] as! [String:Any]
        mixerName = mixerProducts["NAME"] as? String
        mixerPrice = mixerProducts["PRICE"] as? Int
        mixerId = mixerProducts["_id"] as? String
        objQuantity.showQuantity(quantity: 30)
        
      
     
            let info = Info(typeName: mixerName ?? "no value", price: mixerPrice ?? 0)
            mixerData[indexPath.item] = info
       
    }
    
    
    
    
}
