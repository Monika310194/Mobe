//
//  AlertViewDelegate.swift
//  MOBE
//
//  Created by user143649 on 3/20/19.
//  Copyright © 2019 user143649. All rights reserved.
//

import Foundation

protocol CustomAlertViewDelegate: class {
    func positiveTapped()
    func negativeButtonTapped()
}
