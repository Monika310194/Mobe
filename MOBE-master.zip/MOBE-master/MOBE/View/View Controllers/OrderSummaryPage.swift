//
//  OrderSummaryPage.swift
//  FoodTracker
//
//  Created by MacBook-Pro-4 on 04/03/19.
//  Copyright © 2019 Apple Inc. All rights reserved.
//

import UIKit

class OrderSummaryPage: UIViewController {
    
    //OUTLETS:
    @IBOutlet weak var amountView: UIView!
    
    @IBOutlet weak var selectTableView: UIView!
    @IBOutlet weak var totalAmountView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var lblTableNo: UILabel!
    @IBOutlet weak var lblTotalAmount: UILabel!
    
   
    //VARIABLES:
    var selectedTableNo = 0
    var orders:[OrderSummary]?
     let objQuantity = QuanityTableLauncher()
    var tableSelected = false
    var tableRowCount = 0
    var queryDone = false
    //METHODS:
    
    @IBAction func selectTable_Clicked(_ sender: UITapGestureRecognizer) {
        print("selectTable_Clicked")
        if queryDone{
        objQuantity.pageIndex = 2
        objQuantity.showQuantity(quantity: tableRowCount)
        tableSelected = true
        }
    }
    //Notification
    let name = Notification.Name.init(QuantityForSummaryPageNotiKey)
    
    //TIMER
    
    var timerForOrderExpiry = Timer()
    var timerForAlert = Timer()
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "ORDER SUMMARY"
       
       selectTableView.roundCorners(corners: [.allCorners], radius: 4)
        totalAmountView.roundCorners(corners: [.topLeft,.topRight], radius: 4)
        amountView.roundCorners(corners: [.bottomRight,.bottomLeft], radius: 4)
        navigationController?.navigationItem.backBarButtonItem?.title = " "
        //setting the timers
        timerForOrderExpiry = Timer.scheduledTimer(timeInterval: 30, target: self, selector: #selector(handleOrderExpiry), userInfo: nil, repeats: true)
        timerForAlert = Timer.scheduledTimer(timeInterval: 15, target: self, selector: #selector(showAlert), userInfo: nil, repeats: true)
        
        orders = ordersForSummary
         print("orderes summary",orders)
        
       // table/getTableCount
        let url = "https://evening-chamber-14219.herokuapp.com/table/getTableCount"
       
        let networkCall = NetworkHandler()
        networkCall.networkDelegate = self
        networkCall.fetchJSON(url: url)
        
       // navigationItem.leftBarButtonItem = UIBarButtonItem(title: "< Back", style: .plain, target: self, action: #selector(backAction))
       // navigationItem.leftBarButtonItem?.tintColor = .white
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        findTotalAmount()
        lblTableNo.textColor = .cyan
        
         NotificationCenter.default.addObserver(self, selector: #selector(updateQuantity(notification:)), name: name, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        timerForOrderExpiry.invalidate()
        self.timerForAlert.invalidate()
        
    }
     let alert = AlertView()
    @objc func showAlert(){
        alert.delegate = self
        alert.loadAlert(title: "Your order will expire soon", subtitle: "You have 15 seconds more to place the order", negativeAction: "Cancel", positiveAction: "Proceed")
        timerForAlert.invalidate()
    }
    @objc func handleOrderExpiry(){
        //send a order expired notification to viewcontroller
          orderData.removeAll()
        alert.removeAlert()
        let controllers = self.navigationController?.viewControllers
        for vc in controllers! {
            if vc is ViewController {
        (vc as! ViewController).notificationTrue = true
                _ = self.navigationController?.popToViewController(vc as! ViewController, animated: true)
               // let name = Notification.Name.init(orderExpiryNotificationKey)
               // let userInfo : [String:String] = ["notification":"Sorry, Your order has been expired!!"]
                //DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + .seconds(2)) {
                 //   NotificationCenter.default.post(name: name, object: nil, userInfo: userInfo)
             //   }
                
            }
        }
        
    }
    @objc func updateQuantity(notification:Notification){
       if let quantity = notification.userInfo?["quantity"] as? Int
       {
        selectedTableNo = quantity
        lblTableNo.text = "TABLE \(quantity)"
        lblTableNo.textColor = .white
        }
    }
    
    @objc func backAction(){
        //print("Back Button Clicked")
        dismiss(animated: true, completion: nil)
    }
    
    func findTotalAmount(){
        if let orders = orders{
            var totalAmount = 0
            for order in orders{
                let itemPrice = order.price * order.itemCount
                totalAmount += itemPrice
            }
            
            lblTotalAmount.text = "Rs."+"\(totalAmount)"
        }
    }
    
    @IBAction func BtnConfirm_Clicked(_ sender: UIButton) {
        // do POST for the order
        if tableSelected{
            
            var mixerInfo = [Any]()
            if let orders = orders{
            if orders.count>1{
                for i in 1..<ordersForSummary.count{
                    var mixerDic = [String:Any]()
                    mixerDic["MIXER_ID"] = ordersForSummary[i].mixerId
                    mixerDic["MIXER_QUANTITY"] = ordersForSummary[i].itemCount
                    mixerInfo.append(mixerDic)
                }
            }
            }
            orderData["TABLE_ID"] = selectedTableNo
            orderData["MIXER"] = mixerInfo
            print("final order data ",orderData)
            
            //after post clear order data
           
           
            
            guard let Url = URL(string: "https://evening-chamber-14219.herokuapp.com/order/createOrder") else{ return}
            var request = URLRequest(url: Url)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            // guard let httpBody = try? JSONSerialization.data(withJSONObject: patternsDict, options: [])else{return}
            let httpBody =  try? JSONSerialization.data(withJSONObject: orderData)
            request.httpBody = httpBody
            let session = URLSession.shared
            session.dataTask(with: request){(data,response,error)in
                if error == nil{
                    if let response = response{
                        print("response ",response,"\n","data ",data)
                        DispatchQueue.main.async {
                            self.timerForAlert.invalidate()
                            self.timerForOrderExpiry.invalidate()
                            orderData.removeAll()
                            let controllers = self.navigationController?.viewControllers
                            for vc in controllers! {
                                if vc is ViewController {
                                    _ = self.navigationController?.popToViewController(vc as! ViewController, animated: true)
                                }
                            }

                        }
                    }
                }
                else{
                    print("error while posting user info: ",error as! NSError)
                }
                
                }.resume()
            
        }
        else{
            let alert = UIAlertController(title: "Table is not selected", message: "Select the table number", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                alert.dismiss(animated: true, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
extension OrderSummaryPage: CustomAlertViewDelegate{
    func negativeButtonTapped() {
        print("cancel tapped ")
       // let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
    //    let firstVC = storyboard.instantiateViewController(withIdentifier: "first") as! ViewController
          orderData.removeAll()
        let controllers = self.navigationController?.viewControllers
        for vc in controllers! {
            if vc is ViewController {
                _ = self.navigationController?.popToViewController(vc as! ViewController, animated: true)
            }
        }
       
    }
    
    func positiveTapped() {
        print("ok tapped")
    }
    
    
}
extension OrderSummaryPage:UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SummaryCell", for: indexPath)as! OrderSummaryCell
        cell.roundCorners(corners: [.allCorners], radius: 4)
        if let order = orders?[indexPath.row]{
            cell.setUp(order: order)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return orders?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width*0.3
        let height = collectionView.frame.height*0.4
        return CGSize(width: width, height: height)
    }
    
}
extension OrderSummaryPage: NetWorkProtocol{
    func sendJSON(data: Data) {
        
        let data = data
        
        do{
            
            let tableData = try JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [Any]
            
            print(tableData)
            DispatchQueue.main.async {
                self.queryDone = true
                self.tableRowCount = (tableData[0] as! [String:Any])["TABLE_COUNT"] as! Int
                print("tableRowCount ",self.tableRowCount)
                
                CustomLoader.activity.stopLoader()
            }
          
        } catch let jsonErr {
            print("error serialising json :",jsonErr)
        }
        
}
}

