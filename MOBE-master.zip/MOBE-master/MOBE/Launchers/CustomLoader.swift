//
//  CustomLoader.swift
//  Mobe
//
//  Created by user on 07/03/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//


import UIKit

class CustomLoader: UIView
{
    static let activity = CustomLoader()
    
    private lazy var transView: UIView =
    {
        let tV = UIView(frame: UIScreen.main.bounds)
        tV.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        tV.isUserInteractionEnabled = false
        return tV
    }()
    private lazy var gif: UIImageView =
    {
        let gifImage = UIImageView(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        gifImage.contentMode = .scaleAspectFit
        gifImage.center = transView.center
        gifImage.isUserInteractionEnabled = false
        gifImage.loadGif(name: "Brick")
        return gifImage
    }()
    func  startLoader()
    {
        self.addSubview(transView)
        self.transView.addSubview(gif)
        self.transView.bringSubviewToFront(gif)
        UIApplication.shared.keyWindow?.addSubview(transView)
        UIApplication.shared.beginIgnoringInteractionEvents()
        
    }
    func stopLoader()
    {
        
        DispatchQueue.main.async {
            self.transView.removeFromSuperview()
            UIApplication.shared.endIgnoringInteractionEvents()
        }
        
    }
}

