//
//  MenuLauncher.swift
//  Mobe
//
//  Created by user on 24/02/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//


import UIKit
import GoogleSignIn

class MenuLauncher: NSObject{
 
    override init() {
        super.init()
    }
    var homeController: ViewController?
    let menuItems = ["Home","My Orders","About Developers","Share","About us","logOut"]
    let menuImages = ["home","my_order","about_developer","share","about_us","logout"]
     let alert = AlertView()
    var userName = "Namitha"
    
    let blackView: UIView = {
        
        let view = UIView()
        view.backgroundColor = UIColor(white: 0, alpha: 0.5)
        
        return view
    }()
    
    
   // let menuView = UIView()
    
    let tableView = UITableView()
    
    
    func addMenu(){

        if let window = UIApplication.shared.keyWindow{
            window.addSubview(blackView)
            window.addSubview(tableView)
            window.isUserInteractionEnabled = true
            blackView.frame = window.frame
            blackView.alpha = 0
            
            tableView.frame = CGRect(x: 0, y: 0, width: 0, height: window.frame.height)
            
            UIView.animate(withDuration: 0.5) {
                self.blackView.alpha = 1
                self.tableView.frame = CGRect(x: 0, y: 0, width: window.frame.width*0.8, height: window.frame.height)
            }
           
        }
       
        blackView.isUserInteractionEnabled = true
        
        blackView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleDismiss)))
       
       
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(MenuTableCell.self, forCellReuseIdentifier: "menuCell")
        tableView.sectionHeaderHeight = tableView.frame.height*0.25
        
        tableView.separatorStyle = .none
        
        tableView.reloadData()
       
    }
    
    @objc func handleDismiss(){
        print("inside handleDismiss")
        UIView.animate(withDuration: 0.4) {
            self.blackView.alpha = 0
            if let window = UIApplication.shared.keyWindow{
                self.tableView.frame = CGRect(x: 0, y: 0, width: 0, height: window.frame.height)
            }
        }
      blackView.removeFromSuperview()
    }
    func logout(){
      GIDSignIn.sharedInstance().signOut()
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let loginVC = storyboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginVC
        
        let appDel:AppDelegate = UIApplication.shared.delegate as! AppDelegate
        
        appDel.window?.rootViewController = loginVC
    }
   
    
}
extension MenuLauncher: CustomAlertViewDelegate{
    func negativeButtonTapped() {
        print("no tapped")
    }
    
    func positiveTapped() {
        logout()
    }
    
    
}

extension MenuLauncher: UITableViewDataSource,UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "menuCell", for: indexPath) as! MenuTableCell
        cell.lblCatagory.text = menuItems[indexPath.row]
        cell.imagCatagory.image = UIImage(named: menuImages[indexPath.row])
        cell.selectionStyle = .none
        return cell
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuItems.count
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        //table view header view progile image and user name
        let height = tableView.frame.height*0.25
        
        let profileView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: height))
       
      //  profileView.translatesAutoresizingMaskIntoConstraints = false
      
        
        let imgView = UIImageView()
        profileView.addSubview(imgView)
        imgView.image =  UIImage(named:"profileimage")
        imgView.translatesAutoresizingMaskIntoConstraints = false
        //Get the profile image url from user Login structure
        let url = userData?.urlPath
        if let data = try? Data(contentsOf: url!)
        {
            let image: UIImage = UIImage(data: data)!
           imgView.image = image
        }
        imgView.makeRound()
        imgView.contentMode = .scaleAspectFit
       
        let lblUserName = UILabel()
        profileView.addSubview(lblUserName)
        //Get the user name from user login structure
        lblUserName.text = userData?.name
        lblUserName.translatesAutoresizingMaskIntoConstraints = false
        
        let metrics = ["width":profileView.frame.height*0.6]
        imgView.centerYAnchor.constraint(equalTo: profileView.centerYAnchor).isActive = true
       
        let verConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[v0(width)]", options: [], metrics: metrics, views: ["v0":imgView])
        
        
         let horConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:|-[v0(width)]-15-[v1]-|", options: [.alignAllCenterY], metrics: metrics, views: ["v0":imgView,"v1":lblUserName])
        
        profileView.addConstraints(verConstraint)
        
        profileView.addConstraints(horConstraint)
        
        
        return profileView
        
    }
  /*  func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let footerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 40))
        
        let lblLogout = UILabel()
        lblLogout.text = "Log out"
        lblLogout.textColor = UIColor.white
        
        
        let btnFb = UIButton()
        btnFb.contentMode = .scaleAspectFit
        btnFb.backgroundColor = .white
        
        
        let btnInsta = UIButton()
        btnInsta.contentMode = .scaleAspectFit
        btnInsta.backgroundColor = .white
        
        
        let btnTwitter = UIButton()
        btnTwitter.contentMode = .scaleAspectFit
        btnTwitter.backgroundColor = .white
        
        
        var views = [String:UIView]()
        views["v0"] = lblLogout
        views["v1"] = btnFb
        views["v2"] = btnInsta
        views["v3"] = btnTwitter
        
        for (_,value) in views{
            value.translatesAutoresizingMaskIntoConstraints = false
            footerView.addSubview(value)
        }
        
        lblLogout.centerYAnchor.constraint(equalTo: footerView.centerYAnchor).isActive = true
         footerView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-[v0]-[v1(20)]-[v2(20)]-[v3(20)]-|", options: [.alignAllCenterY], metrics: nil, views: views))
        
        btnFb.heightAnchor.constraint(equalToConstant: 20).isActive = true
        btnInsta.heightAnchor.constraint(equalToConstant: 20).isActive = true
        btnTwitter.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        return footerView
    }
     func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
     return 40
     }
     */
    
   
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView.frame.height*0.25
    }
    
   
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 45
    }
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            //Home
            print(" ",indexPath.row)
        case 1:
            //My Orders
            print(" ",indexPath.row)
            handleDismiss()
            homeController?.showOrderHistoryPage()
           // let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
           // let orderVC = storyboard.instantiateViewController(withIdentifier: "OrderHistory") as! OrderHistoryPage
          //  self.present(orderVC, animated: true, completion: nil)
            
        case 2:
            //About Developers
            print(" ",indexPath.row)
        case 3:
            //Share
            print(" ",indexPath.row)
        case 4:
            //About us
            print(" ",indexPath.row)
        case 5:
            //logOut
            print(" ",indexPath.row)
            
           alert.delegate = self
            alert.loadAlert(title: "Logout", subtitle: "Are tou sure?", negativeAction: "No", positiveAction: "Yes")
        
        default:
            print(" ",indexPath.row)
        }
       
    }
}

class MenuTableCell: UITableViewCell{
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    let lblCatagory: UILabel = {
        
        let label = UILabel()
        //Specify label properties here
        label.translatesAutoresizingMaskIntoConstraints = false
        
        return label
        
    }()
    
    let imagCatagory: UIImageView = {
        let image = UIImageView()
        
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }()
    
    func  setUpView(){
        
        print("inside setUpView")
        
        self.contentView.addSubview(imagCatagory)
         self.contentView.addSubview(lblCatagory)
        
        let metrics = ["width":self.contentView.frame.height*0.7]
        imagCatagory.centerYAnchor.constraint(equalTo: self.contentView.centerYAnchor).isActive = true
        let horConstraint = NSLayoutConstraint.constraints(withVisualFormat: "H:|-[v0(width)]-20-[v1]|", options: [.alignAllCenterY], metrics: metrics, views: ["v0":imagCatagory,"v1":lblCatagory])
        let verConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:[v0(width)]", options: [], metrics: metrics, views: ["v0":imagCatagory])
        
        
        self.contentView.addConstraints(horConstraint)
        self.contentView.addConstraints(verConstraint)
    }
}
