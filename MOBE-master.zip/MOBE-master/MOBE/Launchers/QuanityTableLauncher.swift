//
//  QuanityTableLauncher.swift
//  Mobe
//
//  Created by MacBook-Pro-4 on 27/02/19.
//  Copyright © 2019 MacBook-Pro-4. All rights reserved.
//

import Foundation
import UIKit
let QuantityForProductListNotiKey = "co.mobe.quantity1"
let QuantityForMixerPageNotiKey = "co.mobe.quantity2"
let QuantityForSummaryPageNotiKey = "co.mobe.quantity3"

class QuanityTableLauncher:NSObject{
    
    var tableView = UITableView()
    let blackView: UIView = {
        
        let view = UIView()
        view.backgroundColor = UIColor(white: 0, alpha: 0.5)
        
        return view
    }()
    
    var pageIndex = 0
    var Quantity = 0
    var selectedQuantity = 0
    var tapGestureRecognizer: UITapGestureRecognizer?
    func showQuantity(quantity: Int){
        Quantity = quantity
        print("Quantity ",Quantity)
        addTable()
    }
    
    func addTable(){
        
        if let window = UIApplication.shared.keyWindow{
            window.addSubview(blackView)
            window.addSubview(tableView)
            window.isUserInteractionEnabled = true
            blackView.frame = window.frame
            blackView.alpha = 0
            
            let topSpace = window.frame.height*0.2
            let width = window.frame.width*0.8
            let height = blackView.frame.height*0.5
            let x = (window.frame.width - width)/2
            tableView.frame = CGRect(x: x, y: topSpace, width: width, height: height)
            
            tableView.separatorColor = .black
            UIView.animate(withDuration: 0.5) {
                self.blackView.alpha = 1
                self.tableView.alpha = 1
            }
       
        }
        
        blackView.isUserInteractionEnabled = true
       // blackView.addSubview(tableView)
        
        self.tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleDismiss))
       
        if let tapGestureRecognizer = self.tapGestureRecognizer {
            tapGestureRecognizer.cancelsTouchesInView = false
            blackView.addGestureRecognizer(tapGestureRecognizer)
        }
        
        blackView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleDismiss)))
       
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        //Tableview Constraints
        
        tableView.dataSource = self
        tableView.delegate = self
        
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        
    }
    
    @objc func handleDismiss(){
        print("inside handleDismiss")
        UIView.animate(withDuration: 0.5) {
            self.blackView.alpha = 0
            self.tableView.alpha = 0
           // self.tableView.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        }
        
    }
}

extension QuanityTableLauncher: UITableViewDelegate,UITableViewDataSource{
   
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Quantity
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cellForRowAt quantity table")
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as UITableViewCell
        cell.selectionStyle = .none
        cell.textLabel?.text = "\(indexPath.row+1)"
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.textColor = .white
        cell.backgroundColor = UIColor.darkGray
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedQuantity = indexPath.row+1
        if pageIndex == 0{
        orderData["PROD_QUAN"] = selectedQuantity
        print("selectedQuantity ",selectedQuantity ," ",orderData["PROD_QUAN"] ?? 0)
        print("order data ",orderData)
        self.tableView.alpha = 0
            let userInfo: [String:Any] = ["quantity": selectedQuantity]
            
            blackView.removeFromSuperview()
            tableView.removeFromSuperview()
            
        let name = Notification.Name.init(QuantityForProductListNotiKey)
            NotificationCenter.default.post(name: name, object: nil, userInfo: userInfo)
       //showAddMixerPage
        }
        else if pageIndex == 1 {
            self.tableView.alpha = 0
            let userInfo: [String:Any] = ["quantity": selectedQuantity]
            
            blackView.removeFromSuperview()
            tableView.removeFromSuperview()
            
            let name = Notification.Name.init(QuantityForMixerPageNotiKey)
            NotificationCenter.default.post(name: name, object: nil, userInfo: userInfo)
            //fill order data dictionary which we have to post
            //fill ordersummary structure to show in the order summary page
        }
        else if pageIndex == 2{
            
            self.tableView.alpha = 0
            let userInfo: [String:Any] = ["quantity": selectedQuantity]
            
            blackView.removeFromSuperview()
            tableView.removeFromSuperview()
            
            let name = Notification.Name.init(QuantityForSummaryPageNotiKey)
            NotificationCenter.default.post(name: name, object: nil, userInfo: userInfo)
        }
        
     
    }
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int){
        view.tintColor = .black
        let header = view as! UITableViewHeaderFooterView
        header.textLabel!.textColor = .white
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let title = "Select Quantity"
        
        return title
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
     
}
