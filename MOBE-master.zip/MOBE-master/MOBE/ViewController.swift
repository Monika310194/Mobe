//
//  ViewController.swift
//  MOBE
//
//  Created by user143649 on 3/16/19.
//  Copyright © 2019 user143649. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

